# ChatVideoApp

هذا مشروع Android WebView مستقل بدل AppsGeyser. يحتوي على:
- نفس فكرة تطبيق Chat.
- Supabase للمستخدمين والرسائل.
- WebRTC حقيقي للصوت/الفيديو.
- WebViewAssetLoader لفتح HTML من أصل HTTPS داخل التطبيق.
- طلب صلاحيات CAMERA وRECORD_AUDIO من Android.
- WebChromeClient.onPermissionRequest لتمرير صلاحيات WebRTC إلى الصفحة.
- STUN servers من Google للمساعدة في الاتصال المباشر.

## البناء

1. افتح المجلد في Android Studio.
2. انتظر Gradle Sync.
3. شغّل التطبيق على جهاز Android حقيقي.
4. عند أول مكالمة وافق على الكاميرا والمايك.
5. ثبّت التطبيق على جهازين، سجّل بحسابين مختلفين، افتح نفس المحادثة، واضغط 📹 من جهاز واحد.

## مهم

هذا المشروع يحتاج Android Studio/Android SDK لبناء APK. لم يتم تضمين APK جاهز هنا.
إذا ظهر خطأ Gradle بسبب نسخة Android Gradle Plugin، استخدم نسخة Android Studio الحديثة ثم دعها تقترح تحديث نسخة الـplugin.

## Supabase

الـHTML يستخدم نفس بيانات Supabase الموجودة في كودك. يجب أن تكون جداول:
- profiles(username,password)
- message(sender,receiver,text,created_at)

يجب أن تكون Realtime/قاعدة البيانات مضبوطة بما يسمح لتطبيقك بالعمل. يفضّل لاحقًا نقل تسجيل الدخول إلى Supabase Auth وعدم تخزين كلمات المرور كنص صريح.

## WebRTC

إشارات المكالمة (offer/answer/ICE) تمر عبر Supabase Realtime Broadcast في قناة:
call:<اسمين مرتبين>

الفيديو والصوت نفسهما لا يمران عبر Supabase؛ WebRTC يحاول إنشاء اتصال مباشر بين الجهازين. STUN يساعد على اكتشاف مسار الاتصال. في بعض الشبكات الصعبة قد تحتاج TURN server لكي تعمل المكالمة خلف NAT/جدران نارية صارمة.

## لماذا هذا مختلف عن AppsGeyser؟

AppsGeyser هو الذي يتحكم في WebView داخل الـAPK. في هذا المشروع نحن نتحكم في WebView وننفذ:
- CAMERA + RECORD_AUDIO runtime permissions
- WebChromeClient.onPermissionRequest
- WebViewAssetLoader
وهذه الأشياء مطلوبة للوصول إلى الكاميرا والمايك من WebRTC داخل WebView.
